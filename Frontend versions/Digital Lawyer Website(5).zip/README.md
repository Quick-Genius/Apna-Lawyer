
  # Digital Lawyer Website

  This is a code bundle for Digital Lawyer Website. The original project is available at https://www.figma.com/design/ov7akWxq882h0D2oy1tL28/Digital-Lawyer-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  