import { Scale, Mail, Phone, MapPin, Twitter, Linkedin, Github } from "lucide-react";
import { Button } from "./ui/button";

export default function Footer() {
  const footerSections = [
    {
      title: "Apna Lawyer",
      links: [
        { name: "About Us", href: "#" },
        { name: "How It Works", href: "#" },
        { name: "AI Technology", href: "#" },
        { name: "Security & Privacy", href: "#" }
      ]
    },
    {
      title: "Services",
      links: [
        { name: "Document Analysis", href: "#" },
        { name: "Legal AI Chat", href: "#" },
        { name: "Find Lawyers", href: "#" },
        { name: "Legal Community", href: "#" }
      ]
    },
    {
      title: "Legal Areas",
      links: [
        { name: "Contract Law", href: "#" },
        { name: "Corporate Law", href: "#" },
        { name: "Employment Law", href: "#" },
        { name: "Real Estate Law", href: "#" }
      ]
    },
    {
      title: "Support",
      links: [
        { name: "Help Center", href: "#" },
        { name: "Contact Support", href: "#" },
        { name: "Legal Resources", href: "#" },
        { name: "API Documentation", href: "#" }
      ]
    }
  ];

  return (
    <footer className="bg-[#F9FAFB] border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-[#AEC6CF] to-[#89CFF0] rounded-xl flex items-center justify-center shadow-md">
                <Scale className="w-5 h-5 text-[#36454F]" />
              </div>
              <div>
                <h3 className="text-[#36454F]">Apna Lawyer</h3>
                <p className="text-xs text-gray-500">Understand before you sign</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4 leading-relaxed">
              Empowering individuals and businesses with AI-powered legal assistance for clear, understandable legal guidance.
            </p>
            
            {/* Contact Info */}
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#77DDE7]" />
                <span>support@apnalawyer.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#77DDE7]" />
                <span>1-800-APNA-LAW</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#77DDE7]" />
                <span>Mumbai, Maharashtra 400001</span>
              </div>
            </div>
          </div>

          {/* Footer Links */}
          {footerSections.map((section, index) => (
            <div key={index}>
              <h4 className="text-[#36454F] mb-4">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <li key={linkIndex}>
                    <a 
                      href={link.href}
                      className="text-gray-600 hover:text-[#77DDE7] transition-colors text-sm"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter Signup */}
        <div className="border-t border-gray-100 pt-8 mb-8">
          <div className="grid md:grid-cols-2 gap-6 items-center">
            <div>
              <h4 className="text-[#36454F] mb-2">Stay Updated</h4>
              <p className="text-gray-600 text-sm">
                Get the latest legal insights, AI updates, and industry news delivered to your inbox.
              </p>
            </div>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Enter your email address"
                className="flex-1 bg-white border border-gray-200 rounded-xl px-4 py-2 text-[#36454F] placeholder-gray-500 focus:outline-none focus:border-[#AEC6CF]"
              />
              <Button 
                className="bg-[#77DDE7] hover:bg-[#77DDE7]/80 text-[#36454F] px-6 rounded-xl"
                style={{ backgroundColor: '#77DDE7', color: '#36454F' }}
              >
                Subscribe
              </Button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-100 pt-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-gray-600 text-sm">
            © 2024 Apna Lawyer. All rights reserved. | 
            <a href="#" className="hover:text-[#77DDE7] transition-colors ml-1">Privacy Policy</a> | 
            <a href="#" className="hover:text-[#77DDE7] transition-colors ml-1">Terms of Service</a> | 
            <a href="#" className="hover:text-[#77DDE7] transition-colors ml-1">Cookie Policy</a>
          </div>
          
          {/* Social Links */}
          <div className="flex gap-3">
            <Button 
              size="sm" 
              variant="ghost" 
              className="text-gray-600 hover:text-[#77DDE7] hover:bg-gray-50 w-9 h-9 p-0 rounded-lg"
            >
              <Twitter className="w-4 h-4" />
            </Button>
            <Button 
              size="sm" 
              variant="ghost" 
              className="text-gray-600 hover:text-[#77DDE7] hover:bg-gray-50 w-9 h-9 p-0 rounded-lg"
            >
              <Linkedin className="w-4 h-4" />
            </Button>
            <Button 
              size="sm" 
              variant="ghost" 
              className="text-gray-600 hover:text-[#77DDE7] hover:bg-gray-50 w-9 h-9 p-0 rounded-lg"
            >
              <Github className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Legal Disclaimer */}
        <div className="mt-6 pt-6 border-t border-gray-100">
          <p className="text-xs text-gray-500 leading-relaxed">
            <strong className="text-gray-600">Legal Disclaimer:</strong> Apna Lawyer provides AI-powered legal information and document analysis for educational and informational purposes only. This service does not constitute legal advice, create an attorney-client relationship, or replace the need for professional legal counsel. Always consult with a qualified attorney for specific legal matters and decisions.
          </p>
        </div>
      </div>
    </footer>
  );
}