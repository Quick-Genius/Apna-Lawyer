import { useState } from "react";
import Navigation from "./components/Navigation";
import AvatarSelectionPage from "./components/AvatarSelectionPage";
import AIChatPage from "./components/AIChatPage";
import LawyersPage from "./components/LawyersPage";
import CommunityPage from "./components/CommunityPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);

  const handleAvatarSelection = (avatar: string) => {
    setSelectedAvatar(avatar);
    setCurrentPage("chat");
  };

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <AvatarSelectionPage onSelectAvatar={handleAvatarSelection} />;
      case "chat":
        return <AIChatPage selectedAvatar={selectedAvatar || "rohan"} />;
      case "lawyers":
        return <LawyersPage />;
      case "community":
        return <CommunityPage />;
      default:
        return <AvatarSelectionPage onSelectAvatar={handleAvatarSelection} />;
    }
  };

  const showNavigation = currentPage !== "home";

  return (
    <div className="min-h-screen bg-[#FCFCFC]">
      {showNavigation && (
        <Navigation currentPage={currentPage} onPageChange={setCurrentPage} />
      )}
      {renderPage()}
    </div>
  );
}