import React, { useState } from 'react';
import { Scale, MessageCircle, Users, Globe, Search } from 'lucide-react';

interface AppState {
  selectedAvatar: 'male' | 'female' | null;
  uploadedFile: File | null;
  analysisResults: any | null;
  currentStep: 'avatar' | 'upload' | 'analysis' | 'chat';
  language: 'en' | 'hi';
}

function App() {
  const [state, setState] = useState<AppState>({
    selectedAvatar: null,
    uploadedFile: null,
    analysisResults: null,
    currentStep: 'avatar',
    language: 'en'
  });

  const [activeTab, setActiveTab] = useState('home');

  const handleAvatarSelect = (avatar: 'male' | 'female') => {
    setState(prev => ({
      ...prev,
      selectedAvatar: avatar,
      currentStep: 'upload'
    }));
  };

  const toggleLanguage = () => {
    setState(prev => ({
      ...prev,
      language: prev.language === 'en' ? 'hi' : 'en'
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Scale className="w-8 h-8 text-primary" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Apna Lawyer</h1>
                <p className="text-xs text-gray-500">Understand before you sign</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button
                className="btn btn-outline btn-sm flex items-center gap-2"
                onClick={toggleLanguage}
              >
                <Globe className="w-4 h-4" />
                {state.language === 'en' ? 'हिंदी' : 'English'}
              </button>
              
              {state.selectedAvatar && (
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                    <span className="text-white text-sm">
                      {state.selectedAvatar === 'male' ? '👨‍💼' : '👩‍💼'}
                    </span>
                  </div>
                  <span className="text-sm font-medium">Your Assistant</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="w-full">
          <div className="tabs-list grid w-full grid-cols-4 mb-8">
            <button 
              className={`tabs-trigger flex items-center gap-2 ${activeTab === 'home' ? 'data-state-active' : ''}`}
              onClick={() => setActiveTab('home')}
            >
              <Scale className="w-4 h-4" />
              Home
            </button>
            <button 
              className={`tabs-trigger flex items-center gap-2 ${activeTab === 'chat' ? 'data-state-active' : ''}`}
              onClick={() => setActiveTab('chat')}
            >
              <MessageCircle className="w-4 h-4" />
              Chat
            </button>
            <button 
              className={`tabs-trigger flex items-center gap-2 ${activeTab === 'lawyers' ? 'data-state-active' : ''}`}
              onClick={() => setActiveTab('lawyers')}
            >
              <Search className="w-4 h-4" />
              Find Lawyers
            </button>
            <button 
              className={`tabs-trigger flex items-center gap-2 ${activeTab === 'community' ? 'data-state-active' : ''}`}
              onClick={() => setActiveTab('community')}
            >
              <Users className="w-4 h-4" />
              Community
            </button>
          </div>

          {activeTab === 'home' && (
            <div className="space-y-8">
              {state.currentStep === 'avatar' && (
                <div className="text-center py-12">
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">
                    Welcome to Apna Lawyer
                  </h2>
                  <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
                    Your AI-powered legal assistant that simplifies complex legal documents 
                    into clear, actionable guidance. Choose your virtual assistant to get started.
                  </p>
                  
                  <div className="flex flex-col items-center space-y-6">
                    <h2 className="text-2xl font-bold text-center mb-6">Choose Your Legal Assistant</h2>
                    <div className="flex space-x-8">
                      <div className={`card cursor-pointer transition-all duration-300 hover:shadow-lg ${state.selectedAvatar === 'male' ? 'ring-2 ring-blue-500' : ''}`}>
                        <div className="card-content p-6 text-center" onClick={() => handleAvatarSelect('male')}>
                          <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-lg">
                            <div className="text-white text-6xl">👨‍💼</div>
                          </div>
                          <h3 className="text-lg font-semibold mb-2">Legal Expert</h3>
                          <p className="text-sm text-gray-600">Professional male assistant</p>
                          <button 
                            className={`btn mt-4 ${state.selectedAvatar === 'male' ? 'btn-default' : 'btn-outline'}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAvatarSelect('male');
                            }}
                          >
                            {state.selectedAvatar === 'male' ? 'Selected' : 'Choose'}
                          </button>
                        </div>
                      </div>

                      <div className={`card cursor-pointer transition-all duration-300 hover:shadow-lg ${state.selectedAvatar === 'female' ? 'ring-2 ring-pink-500' : ''}`}>
                        <div className="card-content p-6 text-center" onClick={() => handleAvatarSelect('female')}>
                          <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 flex items-center justify-center shadow-lg">
                            <div className="text-white text-6xl">👩‍💼</div>
                          </div>
                          <h3 className="text-lg font-semibold mb-2">Legal Advisor</h3>
                          <p className="text-sm text-gray-600">Professional female assistant</p>
                          <button 
                            className={`btn mt-4 ${state.selectedAvatar === 'female' ? 'btn-default' : 'btn-outline'}`}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAvatarSelect('female');
                            }}
                          >
                            {state.selectedAvatar === 'female' ? 'Selected' : 'Choose'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {state.currentStep === 'upload' && state.selectedAvatar && (
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="flex flex-col items-center">
                      <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-lg">
                        <div className="text-white text-6xl">{state.selectedAvatar === 'male' ? '👨‍💼' : '👩‍💼'}</div>
                      </div>
                      <div className="bg-white rounded-lg shadow-lg p-4 max-w-md relative">
                        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-white rotate-45"></div>
                        <p className="text-gray-800 text-center">
                          Hello! I'm your legal assistant. I'm here to help you understand complex legal documents. 
                          How can I assist you today?
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="card w-full max-w-2xl mx-auto">
                    <div className="card-header">
                      <h3 className="card-title flex items-center gap-2">
                        <MessageCircle className="w-5 h-5" />
                        Upload Legal Document
                      </h3>
                    </div>
                    <div className="card-content">
                      <div className="border-2 border-dashed rounded-lg p-8 text-center transition-colors border-gray-300 hover:border-gray-400">
                        <div className="flex flex-col items-center space-y-4">
                          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                            <MessageCircle className="w-8 h-8 text-gray-400" />
                          </div>
                          
                          <div>
                            <p className="text-lg font-medium text-gray-900 mb-2">
                              Drop your legal document here
                            </p>
                            <p className="text-sm text-gray-500 mb-4">
                              or click to browse files
                            </p>
                            <p className="text-xs text-gray-400">
                              Supports PDF, Word documents, and images (OCR)
                            </p>
                          </div>

                          <button className="btn btn-outline">
                            Choose File
                          </button>
                        </div>
                      </div>

                      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-medium text-blue-900 mb-2">What happens next?</h4>
                        <ul className="text-sm text-blue-800 space-y-1">
                          <li>• AI will analyze your document structure</li>
                          <li>• Each clause will be explained in simple terms</li>
                          <li>• You'll get risk assessments and recommendations</li>
                          <li>• Ask questions about specific terms or conditions</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="text-center py-12">
              <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Select an Avatar First
              </h3>
              <p className="text-gray-500 mb-4">
                Please go to the Home tab and select your legal assistant avatar to start chatting.
              </p>
              <button className="btn btn-default" onClick={() => setActiveTab('home')}>
                Go to Home
              </button>
            </div>
          )}

          {activeTab === 'lawyers' && (
            <div className="text-center py-12">
              <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Find Legal Experts
              </h3>
              <p className="text-gray-500">
                Coming soon - Search for qualified lawyers in your area.
              </p>
            </div>
          )}

          {activeTab === 'community' && (
            <div className="text-center py-12">
              <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Legal Community
              </h3>
              <p className="text-gray-500">
                Coming soon - Join legal discussion groups and get updates.
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <Scale className="w-6 h-6 text-primary" />
              <span className="text-lg font-semibold">Apna Lawyer</span>
            </div>
            <p className="text-sm text-gray-500">
              Making legal documents accessible to everyone. Powered by AI, guided by experts.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
